# TaskMate Telegram Bot — Документация для воссоздания

## Обзор

Telegram бот для системы управления задачами автосалонов. Интегрирован с Laravel бэкендом.

## 🛠 Технологии

- **Framework**: Laravel 12 (PHP 8.4)
- **Telegram SDK**: [Nutgram](https://nutgram.dev) (`nutgram/laravel` ^1.5)
- **Cache**: Valkey (Redis-compatible)
- **Database**: PostgreSQL

## 📦 Установка Nutgram

```bash
composer require nutgram/laravel
php artisan vendor:publish --provider="Nutgram\Laravel\NutgramServiceProvider"
```

## 🔧 Конфигурация `config/nutgram.php`

```php
return [
    'token' => env('TELEGRAM_TOKEN'),
    'safe_mode' => env('APP_ENV', 'local') === 'production',
    'config' => [],
    'routes' => true,  // Автозагрузка routes/telegram.php
    'mixins' => false,
    'namespace' => app_path('Bot'),
    'log_channel' => env('TELEGRAM_LOG_CHANNEL', 'null'),
    'conversationTtl' => 43200, // 24 часа
];
```

## 🏗 Архитектура бота

### Структура папок

```
app/Bot/
├── Abstracts/
│   ├── BaseCallbackHandler.php    # Базовый обработчик callback
│   ├── BaseCommandHandler.php     # Базовый обработчик команд
│   ├── BaseConversation.php       # Базовый диалог с KeyboardTrait
│   └── BaseConversationHandler.php
├── Commands/
│   ├── Employee/
│   │   ├── CloseShiftCommand.php  # /closeshift
│   │   ├── OpenShiftCommand.php   # /openshift
│   │   └── StartCommand.php
│   ├── Manager/
│   │   ├── StartCommand.php
│   │   ├── ViewShiftsCommand.php  # Просмотр смен
│   │   └── ViewTasksCommand.php   # Просмотр задач
│   ├── Observer/
│   │   ├── StartCommand.php
│   │   ├── ViewShiftsCommand.php
│   │   └── ViewTasksCommand.php
│   └── Owner/
│       ├── StartCommand.php
│       ├── ViewDealershipsCommand.php
│       ├── ViewEmployeesCommand.php
│       ├── ViewShiftsCommand.php
│       └── ViewTasksCommand.php
├── Contracts/
│   ├── CallbackHandlerInterface.php
│   ├── CommandHandlerInterface.php
│   └── ConversationInterface.php
├── Conversations/
│   ├── Employee/
│   │   ├── CloseShiftConversation.php  # Диалог закрытия смены с фото
│   │   └── OpenShiftConversation.php   # Диалог открытия смены с фото
│   └── Guest/
│       └── StartConversation.php       # Аутентификация по телефону
├── Dispatchers/
│   ├── StartConversationDispatcher.php
│   ├── ViewShiftsDispatcher.php
│   └── ViewTasksDispatcher.php
├── Handlers/
│   └── TaskResponseHandler.php  # Отклики на задачи (OK, Выполнено)
└── Middleware/
    ├── AuthUser.php              # Проверка авторизации
    └── RoleMiddleware.php        # Проверка роли
```

### Вспомогательные файлы

```
app/Traits/KeyboardTrait.php           # Генерация Telegram клавиатур
app/Services/TelegramNotificationService.php  # Уведомления через бота
app/Services/TaskNotificationService.php      # Уведомления о задачах
app/Services/ManagerNotificationService.php   # Уведомления менеджерам
routes/telegram.php                    # Роуты бота
```

## 👥 Ролевая модель

| Роль | Функции |
|------|---------|
| **Employee** | Открытие/закрытие смены, отклики на задачи |
| **Manager** | Просмотр смен и задач сотрудников |
| **Observer** | Только просмотр (read-only) |
| **Owner** | Полный доступ: салоны, сотрудники, смены, задачи |

## 🔐 Аутентификация

Пользователь делится номером телефона → система находит по `phone` поле → привязывает `telegram_id`.

### Важная логика

1. Нормализация телефона (удаление `+`, замена `8` на `7` для РФ)
2. Поиск по нескольким форматам (`+79991234567`, `89991234567`, `9991234567`)
3. Защита от повторной привязки другого Telegram аккаунта

## ⌨️ Клавиатуры (KeyboardTrait)

```php
// Меню сотрудника
public static function employeeMenu(): ReplyKeyboardMarkup
{
    return ReplyKeyboardMarkup::make(resize_keyboard: true)
        ->addRow(
            KeyboardButton::make('🔓 Открыть смену'),
            KeyboardButton::make('🔒 Закрыть смену')
        );
}

// Запрос контакта
public static function contactRequestKeyboard(): ReplyKeyboardMarkup
{
    return ReplyKeyboardMarkup::make(resize_keyboard: true, one_time_keyboard: true)
        ->addRow(KeyboardButton::make('Отправить номер', request_contact: true));
}

// Inline кнопки для задач
public static function inlineConfirmDecline($confirmData, $declineData): InlineKeyboardMarkup
{
    return InlineKeyboardMarkup::make()
        ->addRow(
            InlineKeyboardButton::make(text: '✅ Подтвердить', callback_data: $confirmData),
            InlineKeyboardButton::make(text: '❌ Отменить', callback_data: $declineData),
        );
}
```

## 📬 Уведомления о задачах

### Типы уведомлений

| Тип | Описание | Канал настроек |
|-----|----------|----------------|
| task_assigned | Новая задача назначена | CHANNEL_TASK_ASSIGNED |
| deadline_30min | За 30 мин до дедлайна | CHANNEL_TASK_DEADLINE_30MIN |
| overdue | Дедлайн истёк | CHANNEL_TASK_OVERDUE |
| hour_late | Просрочено на 1 час | CHANNEL_TASK_HOUR_LATE |

### Пример отправки

```php
public function sendTaskToUser(Task $task, User $user): bool
{
    if (!$user->telegram_id) return false;
    
    $message = $this->formatTaskMessage($task, 'regular');
    $keyboard = $this->getTaskKeyboard($task);
    
    $this->bot->sendMessage(
        text: $message,
        chat_id: $user->telegram_id,
        parse_mode: 'Markdown',
        reply_markup: $keyboard
    );
    
    return true;
}
```

## 🔄 Диалоги (Conversations)

### OpenShiftConversation — открытие смены с фото

1. Запрос фото рабочего места
2. Сохранение фото в Storage
3. Создание записи Shift в БД
4. Подтверждение пользователю

### StartConversation — аутентификация

1. Запрос контакта (номер телефона)
2. Нормализация номера
3. Поиск пользователя в БД
4. Привязка telegram_id
5. Показ ролевого меню

## 📡 Роутинг `routes/telegram.php`

```php
use SergiX44\Nutgram\Nutgram;
use App\Bot\Middleware\AuthUser;

// Команда /start — без авторизации
$bot->onCommand('start', StartConversationDispatcher::class);

// Группа авторизованных команд
$bot->group(function (Nutgram $bot) {
    $bot->onCommand('openshift', OpenShiftCommand::class)->middleware(AuthUser::class);
    $bot->onCommand('closeshift', CloseShiftCommand::class)->middleware(AuthUser::class);
    
    // Текстовые кнопки
    $bot->onText('🔓 Открыть смену', OpenShiftCommand::class)->middleware(AuthUser::class);
    $bot->onText('📊 Смены', ViewShiftsDispatcher::class)->middleware(AuthUser::class);
    
    // Callback для задач
    $bot->onCallbackQueryData('task_ok_{taskId}', TaskResponseHandler::class . '@handleOk')
        ->middleware(AuthUser::class);
});
```

## 🔌 Middleware

### AuthUser.php

```php
public function __invoke(Nutgram $bot, $next): void
{
    $telegramId = $bot->user()?->id;
    
    $user = User::where('telegram_id', $telegramId)->first();
    
    if (!$user) {
        $bot->sendMessage('❌ Вы не авторизованы. Используйте /start');
        return;
    }
    
    // Сохраняем user в контексте бота
    $bot->set('user', $user);
    
    $next($bot);
}
```

## 📊 Модель User — поля для бота

```php
// В таблице users
'telegram_id' => nullable, bigInteger  // ID пользователя в Telegram
'phone' => string                       // Телефон для аутентификации
'role' => enum (employee/manager/observer/owner)
```

## ⏰ Jobs для уведомлений

| Job | Описание |
|-----|----------|
| CheckUpcomingDeadlinesJob | Проверка приближающихся дедлайнов |
| CheckOverdueTasksJob | Проверка просроченных задач |
| CheckHourlyOverdueJob | Проверка задач просроченных на час |
| CheckUnrespondedTasksJob | Напоминание о задачах без ответа |
| SendWeeklyReportJob | Еженедельный отчёт |
| SendScheduledTasksJob | Отправка запланированных задач |

## 🌍 ENV переменные

```env
TELEGRAM_TOKEN=123456:ABC-DEF...
TELEGRAM_LOG_CHANNEL=null
NUTGRAM_LOG_CHAT_ID=  # Chat ID для логов ошибок
```

## 🚀 Webhook Setup

```bash
# Установка webhook
php artisan nutgram:hook:set

# Удаление webhook (для polling)
php artisan nutgram:hook:remove

# Запуск polling (dev)
php artisan nutgram:polling
```

## 📸 Хранение фото смен

Фото сохраняются через Laravel Storage в `storage/app/shifts/`.
При закрытии смены требуется фото для подтверждения.

## 🧪 Тестирование

Nutgram предоставляет `FakeNutgram` для unit-тестов:

```php
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Testing\FakeNutgram;

$bot = Nutgram::fake();

$bot->hearText('/start')
    ->reply()
    ->assertText('Добро пожаловать!');
```

## 📁 Файлы для бэкапа

Для полного восстановления нужны:

1. `app/Bot/` — вся папка
2. `app/Traits/KeyboardTrait.php`
3. `app/Services/TelegramNotificationService.php`
4. `app/Services/TaskNotificationService.php`  
5. `app/Services/ManagerNotificationService.php`
6. `routes/telegram.php`
7. `config/nutgram.php`
8. `tests/Feature/Bot/` — тесты
9. Миграции с `telegram_id`

---

**Архив создан**: Дата создания бэкапа будет указана в имени ZIP файла.
